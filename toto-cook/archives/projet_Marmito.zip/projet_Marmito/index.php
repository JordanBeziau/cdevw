<!DOCTYPE html>
<html>
	<head>
    <meta charset="utf-8">
    <title>PROJET MARMITO - Page HTML5 vierge</title>
		<link rel="stylesheet" href="css/normalisation.css" >
		<link rel="stylesheet" href="css/style.css" >
		<script src="scripts/fonctions.js"></script>
		<script>
			document.addEventListener('DOMContentLoaded', function() {

			});
		</script>
  </head>
	<body>

	</body>
</html>
